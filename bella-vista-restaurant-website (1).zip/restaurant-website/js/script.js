$(document).ready(function () {
  // ========== PAGE LOADER ==========
  setTimeout(function () {
    $('.page-loader').addClass('hidden');
  }, 800);

  // ========== DARK MODE ==========
  const savedTheme = localStorage.getItem('bellaTheme') || 'light';
  if (savedTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    $('.theme-toggle i').removeClass('fa-moon').addClass('fa-sun');
  }

  $('.theme-toggle').on('click', function () {
    const current = document.documentElement.getAttribute('data-theme');
    if (current === 'dark') {
      document.documentElement.removeAttribute('data-theme');
      localStorage.setItem('bellaTheme', 'light');
      $(this).find('i').removeClass('fa-sun').addClass('fa-moon');
    } else {
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('bellaTheme', 'dark');
      $(this).find('i').removeClass('fa-moon').addClass('fa-sun');
    }
  });

  // ========== NAVBAR SCROLL ==========
  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 50) {
      $('.navbar').addClass('scrolled');
    } else {
      $('.navbar').removeClass('scrolled');
    }
    if ($(this).scrollTop() > 300) {
      $('.back-to-top').addClass('show');
    } else {
      $('.back-to-top').removeClass('show');
    }
    $('.fade-in').each(function () {
      var elementTop = $(this).offset().top;
      var viewportBottom = $(window).scrollTop() + $(window).height() - 80;
      if (elementTop < viewportBottom) {
        $(this).addClass('visible');
      }
    });
  });
  $(window).trigger('scroll');

  // ========== BACK TO TOP ==========
  $('.back-to-top').on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 600);
  });

  // ========== SMOOTH SCROLL ==========
  $('a[href^="#"]').on('click', function (e) {
    var target = $(this.getAttribute('href'));
    if (target.length) {
      e.preventDefault();
      $('html, body').stop().animate({ scrollTop: target.offset().top - 70 }, 800);
    }
  });

  // ========== ACTIVE NAV ==========
  var currentPage = window.location.pathname.split('/').pop() || 'index.html';
  $('.navbar-nav .nav-link').each(function () {
    var link = $(this).attr('href');
    if (link === currentPage || (currentPage === '' && link === 'index.html')) {
      $(this).addClass('active');
    }
  });

  // ========== MENU FILTER + SEARCH ==========
  $('.filter-btn').on('click', function () {
    var filter = $(this).data('filter');
    $('.filter-btn').removeClass('active');
    $(this).addClass('active');
    filterMenu(filter, $('#menuSearch').val());
  });

  $('#menuSearch').on('input', function () {
    var activeFilter = $('.filter-btn.active').data('filter') || 'all';
    filterMenu(activeFilter, $(this).val());
  });

  function filterMenu(filter, searchTerm) {
    searchTerm = (searchTerm || '').toLowerCase().trim();
    $('.menu-item').each(function () {
      var $item = $(this);
      var category = $item.data('category');
      var name = $item.find('h5').text().toLowerCase();
      var desc = $item.find('p').text().toLowerCase();
      var matchCategory = (filter === 'all' || category === filter);
      var matchSearch = (!searchTerm || name.includes(searchTerm) || desc.includes(searchTerm));
      if (matchCategory && matchSearch) {
        $item.fadeIn(350);
      } else {
        $item.hide();
      }
    });
  }

  // ========== CART ==========
  let cart = JSON.parse(localStorage.getItem('bellaCart')) || [];

  function updateCartUI() {
    const $cartBody = $('.cart-body');
    const $badges = $('.cart-badge');
    const $total = $('.cart-total-price');
    const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);

    if (cart.length === 0) {
      $cartBody.html(`
        <div class="empty-cart-msg">
          <i class="fas fa-shopping-bag"></i>
          <p>Your cart is empty</p>
          <small>Add delicious items from our menu!</small>
        </div>
      `);
      $badges.text('0').hide();
      $total.text('$0.00');
      return;
    }

    $badges.text(totalQty).show();
    let html = '';
    let total = 0;

    cart.forEach((item, index) => {
      const itemTotal = item.price * item.qty;
      total += itemTotal;
      html += `
        <div class="cart-item">
          <img src="${item.img}" alt="${item.name}">
          <div class="cart-item-details">
            <h6>${item.name}</h6>
            <div class="text-muted small">$${item.price.toFixed(2)} each</div>
            <div class="cart-qty">
              <button class="qty-minus" data-index="${index}" aria-label="Decrease">−</button>
              <span>${item.qty}</span>
              <button class="qty-plus" data-index="${index}" aria-label="Increase">+</button>
              <button class="btn btn-sm text-danger ms-2 remove-item" data-index="${index}" title="Remove"><i class="fas fa-trash-alt"></i></button>
            </div>
          </div>
          <div class="fw-bold">$${itemTotal.toFixed(2)}</div>
        </div>
      `;
    });

    $cartBody.html(html);
    $total.text('$' + total.toFixed(2));
    localStorage.setItem('bellaCart', JSON.stringify(cart));
  }

  // Add to cart
  $(document).on('click', '.add-btn, .add-to-cart', function (e) {
    e.preventDefault();
    const $btn = $(this);
    const name = $btn.data('name');
    const price = parseFloat($btn.data('price'));
    const img = $btn.data('img');

    const existing = cart.find(item => item.name === name);
    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({ name, price, img, qty: 1 });
    }

    updateCartUI();

    // Button feedback
    const original = $btn.html();
    $btn.html('<i class="fas fa-check"></i>');
    $btn.css('background', '#28a745');
    setTimeout(() => {
      $btn.html(original);
      $btn.css('background', '');
    }, 900);

    showToast(name + ' added to cart!', 'success');
  });

  $(document).on('click', '.qty-plus', function () {
    const index = $(this).data('index');
    cart[index].qty += 1;
    updateCartUI();
  });

  $(document).on('click', '.qty-minus', function () {
    const index = $(this).data('index');
    if (cart[index].qty > 1) {
      cart[index].qty -= 1;
    } else {
      cart.splice(index, 1);
    }
    updateCartUI();
  });

  $(document).on('click', '.remove-item', function () {
    const index = $(this).data('index');
    const removed = cart[index].name;
    cart.splice(index, 1);
    updateCartUI();
    showToast(removed + ' removed', 'warning');
  });

  // Open cart
  $(document).on('click', '.cart-toggle, .floating-cart', function (e) {
    e.preventDefault();
    $('.cart-sidebar').addClass('open');
    $('.cart-overlay').addClass('show');
    $('body').css('overflow', 'hidden');
  });

  // Close cart
  $(document).on('click', '.close-cart, .cart-overlay', function () {
    $('.cart-sidebar').removeClass('open');
    $('.cart-overlay').removeClass('show');
    $('body').css('overflow', '');
  });

  // Checkout
  $('.checkout-btn').on('click', function () {
    if (cart.length === 0) {
      showToast('Your cart is empty!', 'warning');
      return;
    }
    const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
    $('#orderSuccessMsg').text(`Your order totaling $${total.toFixed(2)} has been placed successfully! We will contact you soon.`);
    const modal = new bootstrap.Modal(document.getElementById('orderSuccessModal'));
    modal.show();
    cart = [];
    updateCartUI();
    $('.cart-sidebar').removeClass('open');
    $('.cart-overlay').removeClass('show');
    $('body').css('overflow', '');
  });

  updateCartUI();

  // ========== RESERVATION FORM ==========
  $('#reservationForm').on('submit', function (e) {
    e.preventDefault();
    const name = $('#resName').val().trim();
    const email = $('#resEmail').val().trim();
    const phone = $('#resPhone').val().trim();
    const date = $('#resDate').val();
    const time = $('#resTime').val();
    const guests = $('#resGuests').val();

    if (!name || !email || !phone || !date || !time || !guests) {
      showAlert('#reservationAlert', 'Please fill in all required fields.', 'danger');
      return;
    }
    if (!isValidEmail(email)) {
      showAlert('#reservationAlert', 'Please enter a valid email address.', 'danger');
      return;
    }

    const msg = `Thank you, ${name}! Your table for ${guests} on ${formatDate(date)} at ${time} is reserved. Confirmation sent to ${email}.`;
    showAlert('#reservationAlert', msg, 'success');
    this.reset();
  });

  // ========== CONTACT FORM ==========
  $('#contactForm').on('submit', function (e) {
    e.preventDefault();
    const name = $('#contactName').val().trim();
    const email = $('#contactEmail').val().trim();
    const subject = $('#contactSubject').val().trim();
    const message = $('#contactMessage').val().trim();

    if (!name || !email || !subject || !message) {
      showAlert('#contactAlert', 'Please fill in all fields.', 'danger');
      return;
    }
    if (!isValidEmail(email)) {
      showAlert('#contactAlert', 'Please enter a valid email address.', 'danger');
      return;
    }
    showAlert('#contactAlert', `Thank you, ${name}! Your message has been sent. We will reply soon.`, 'success');
    this.reset();
  });

  // ========== NEWSLETTER ==========
  $('.newsletter-form').on('submit', function (e) {
    e.preventDefault();
    const email = $(this).find('input[type="email"]').val().trim();
    if (!email || !isValidEmail(email)) {
      showToast('Please enter a valid email', 'warning');
      return;
    }
    showToast('Successfully subscribed to our newsletter!', 'success');
    $(this).find('input').val('');
  });

  // ========== GALLERY MODAL ==========
  $('.gallery-item').on('click', function () {
    const imgSrc = $(this).find('img').attr('src');
    const title = $(this).data('title') || 'Gallery Image';
    $('#galleryModalImg').attr('src', imgSrc);
    $('#galleryModalLabel').text(title);
    const modal = new bootstrap.Modal(document.getElementById('galleryModal'));
    modal.show();
  });

  // ========== DATE MIN ==========
  const today = new Date().toISOString().split('T')[0];
  $('#resDate').attr('min', today);

  // ========== HELPERS ==========
  function showToast(message, type = 'success') {
    const bg = type === 'success' ? 'bg-success' : type === 'warning' ? 'bg-warning text-dark' : 'bg-danger';
    const toastHtml = `
      <div class="toast align-items-center text-white ${bg} border-0 position-fixed bottom-0 end-0 m-3" role="alert" style="z-index:9999">
        <div class="d-flex">
          <div class="toast-body">${message}</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    `;
    const $toast = $(toastHtml);
    $('body').append($toast);
    const toast = new bootstrap.Toast($toast[0], { delay: 2800 });
    toast.show();
    $toast.on('hidden.bs.toast', function () { $(this).remove(); });
  }

  function showAlert(selector, message, type) {
    const $alert = $(selector);
    $alert.removeClass('d-none alert-success alert-danger alert-warning')
      .addClass('alert-' + type)
      .html('<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'exclamation-circle') + ' me-2"></i>' + message)
      .fadeIn();
    setTimeout(() => { $alert.fadeOut(); }, 7000);
  }

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function formatDate(dateStr) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateStr).toLocaleDateString('en-US', options);
  }

  // ========== COUNTERS ==========
  function animateCounters() {
    $('.counter').each(function () {
      const $this = $(this);
      if ($this.hasClass('counted')) return;
      const target = parseInt($this.data('target'));
      const elementTop = $this.offset().top;
      const viewportBottom = $(window).scrollTop() + $(window).height();
      if (elementTop < viewportBottom - 40) {
        $this.addClass('counted');
        $({ count: 0 }).animate({ count: target }, {
          duration: 2000,
          easing: 'swing',
          step: function () { $this.text(Math.floor(this.count).toLocaleString()); },
          complete: function () { $this.text(target.toLocaleString()); }
        });
      }
    });
  }
  $(window).on('scroll', animateCounters);
  animateCounters();
});
