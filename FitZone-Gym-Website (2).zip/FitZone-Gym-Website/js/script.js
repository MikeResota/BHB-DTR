/* ============================================
   FitZone Gym - Main JavaScript
   Cart, Animations, Forms, Interactions
   ============================================ */

$(document).ready(function () {
  // ========== PRELOADER ==========
  setTimeout(function () {
    $('.spinner-overlay').addClass('hidden');
  }, 800);

  // ========== NAVBAR SCROLL ==========
  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 50) {
      $('.navbar').addClass('scrolled');
      $('.back-to-top').addClass('show');
    } else {
      $('.navbar').removeClass('scrolled');
      $('.back-to-top').removeClass('show');
    }
  });

  // ========== BACK TO TOP ==========
  $('.back-to-top').on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 600);
  });

  // ========== SMOOTH SCROLL ==========
  $('a[href^="#"]').on('click', function (e) {
    var target = $(this.getAttribute('href'));
    if (target.length) {
      e.preventDefault();
      $('html, body').stop().animate({
        scrollTop: target.offset().top - 80
      }, 600);
    }
  });

  // ========== ACTIVE NAV LINK ==========
  var currentPage = window.location.pathname.split('/').pop() || 'index.html';
  $('.navbar-nav .nav-link').each(function () {
    var href = $(this).attr('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      $(this).addClass('active');
    }
  });

  // ========== ANIMATE ON SCROLL ==========
  function checkVisibility() {
    $('.animate-on-scroll').each(function () {
      var elTop = $(this).offset().top;
      var elBottom = elTop + $(this).outerHeight();
      var viewTop = $(window).scrollTop();
      var viewBottom = viewTop + $(window).height();

      if (elBottom > viewTop + 100 && elTop < viewBottom - 50) {
        $(this).addClass('visible');
      }
    });
  }
  checkVisibility();
  $(window).on('scroll', checkVisibility);

  // ========== COUNTER ANIMATION ==========
  function animateCounters() {
    $('.stat-number').each(function () {
      var $this = $(this);
      if ($this.hasClass('counted')) return;
      var elTop = $this.offset().top;
      var viewBottom = $(window).scrollTop() + $(window).height();
      if (elTop < viewBottom - 50) {
        $this.addClass('counted');
        var target = parseInt($this.data('target')) || parseInt($this.text());
        $({ count: 0 }).animate({ count: target }, {
          duration: 2000,
          easing: 'swing',
          step: function () {
            $this.text(Math.floor(this.count) + ($this.data('suffix') || ''));
          },
          complete: function () {
            $this.text(target + ($this.data('suffix') || ''));
          }
        });
      }
    });
  }
  animateCounters();
  $(window).on('scroll', animateCounters);

  // ========== CART SYSTEM ==========
  var cart = JSON.parse(localStorage.getItem('fitzone_cart')) || [];

  function saveCart() {
    localStorage.setItem('fitzone_cart', JSON.stringify(cart));
    updateCartUI();
  }

  function updateCartUI() {
    var totalItems = 0;
    var totalPrice = 0;

    cart.forEach(function (item) {
      totalItems += item.qty;
      totalPrice += item.price * item.qty;
    });

    $('.cart-count').text(totalItems);
    if (totalItems === 0) {
      $('.cart-count').hide();
    } else {
      $('.cart-count').show();
    }

    // Update cart sidebar
    var $body = $('.cart-body');
    $body.empty();

    if (cart.length === 0) {
      $body.html(
        '<div class="cart-empty">' +
        '<i class="bi bi-cart-x"></i>' +
        '<p>Your cart is empty</p>' +
        '<a href="shop.html" class="btn btn-primary-custom btn-sm mt-2">Browse Shop</a>' +
        '</div>'
      );
      $('.cart-footer').hide();
    } else {
      cart.forEach(function (item, index) {
        $body.append(
          '<div class="cart-item" data-index="' + index + '">' +
          '<img src="' + item.image + '" alt="' + item.name + '">' +
          '<div class="cart-item-info">' +
          '<h6>' + item.name + '</h6>' +
          '<div class="price">$' + item.price.toFixed(2) + '</div>' +
          '<div class="qty-controls">' +
          '<button class="qty-minus" data-index="' + index + '">−</button>' +
          '<span>' + item.qty + '</span>' +
          '<button class="qty-plus" data-index="' + index + '">+</button>' +
          '</div></div>' +
          '<button class="cart-item-remove" data-index="' + index + '"><i class="bi bi-trash"></i></button>' +
          '</div>'
        );
      });
      $('.cart-footer').show();
      $('.cart-total-price').text('$' + totalPrice.toFixed(2));
    }
  }

  // Open / Close cart
  $('.cart-btn, .open-cart').on('click', function (e) {
    e.preventDefault();
    $('.cart-sidebar').addClass('open');
    $('.cart-overlay').addClass('show');
    $('body').css('overflow', 'hidden');
  });

  $('.cart-close, .cart-overlay').on('click', function () {
    $('.cart-sidebar').removeClass('open');
    $('.cart-overlay').removeClass('show');
    $('body').css('overflow', '');
  });

  // Add to cart
  $(document).on('click', '.btn-add-cart', function () {
    var $btn = $(this);
    var id = $btn.data('id');
    var name = $btn.data('name');
    var price = parseFloat($btn.data('price'));
    var image = $btn.data('image');

    var existing = cart.find(function (item) { return item.id === id; });
    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({ id: id, name: name, price: price, image: image, qty: 1 });
    }
    saveCart();
    showToast(name + ' added to cart!');
  });

  // Quantity controls
  $(document).on('click', '.qty-plus', function () {
    var index = $(this).data('index');
    cart[index].qty += 1;
    saveCart();
  });

  $(document).on('click', '.qty-minus', function () {
    var index = $(this).data('index');
    if (cart[index].qty > 1) {
      cart[index].qty -= 1;
    } else {
      cart.splice(index, 1);
    }
    saveCart();
  });

  // Remove item
  $(document).on('click', '.cart-item-remove', function () {
    var index = $(this).data('index');
    var name = cart[index].name;
    cart.splice(index, 1);
    saveCart();
    showToast(name + ' removed from cart');
  });

  // Clear cart
  $('.clear-cart').on('click', function () {
    cart = [];
    saveCart();
    showToast('Cart cleared');
  });

  // Checkout
  $('.btn-checkout').on('click', function () {
    if (cart.length === 0) {
      showToast('Your cart is empty!');
      return;
    }
    $('#checkoutModal').modal('show');
    // Populate summary
    var html = '';
    var total = 0;
    cart.forEach(function (item) {
      var sub = item.price * item.qty;
      total += sub;
      html += '<div class="d-flex justify-content-between mb-2"><span>' + item.name + ' × ' + item.qty + '</span><span>$' + sub.toFixed(2) + '</span></div>';
    });
    html += '<hr style="border-color:rgba(255,255,255,0.1)"><div class="d-flex justify-content-between fw-bold"><span>Total</span><span class="text-primary">$' + total.toFixed(2) + '</span></div>';
    $('#checkout-summary').html(html);
  });

  // Place order
  $('#place-order-btn').on('click', function () {
    var name = $('#checkout-name').val().trim();
    var email = $('#checkout-email').val().trim();
    var phone = $('#checkout-phone').val().trim();
    var address = $('#checkout-address').val().trim();

    if (!name || !email || !phone || !address) {
      showToast('Please fill in all fields');
      return;
    }

    // Simulate order
    $(this).prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Processing...');

    setTimeout(function () {
      cart = [];
      saveCart();
      $('#checkoutModal').modal('hide');
      $('#place-order-btn').prop('disabled', false).text('Place Order');
      $('#checkout-form')[0].reset();
      $('.cart-sidebar').removeClass('open');
      $('.cart-overlay').removeClass('show');
      $('body').css('overflow', '');
      showToast('Order placed successfully! Thank you.');
    }, 1500);
  });

  // Init cart UI
  updateCartUI();

  // ========== PRODUCT FILTER ==========
  $('.filter-btn').on('click', function () {
    var filter = $(this).data('filter');
    $('.filter-btn').removeClass('active');
    $(this).addClass('active');

    if (filter === 'all') {
      $('.product-card').parent().fadeIn(300);
    } else {
      $('.product-card').parent().hide();
      $('.product-card[data-category="' + filter + '"]').parent().fadeIn(300);
    }
  });

  // ========== CONTACT FORM ==========
  $('#contact-form').on('submit', function (e) {
    e.preventDefault();
    var name = $('#contact-name').val().trim();
    var email = $('#contact-email').val().trim();
    var subject = $('#contact-subject').val().trim();
    var message = $('#contact-message').val().trim();

    if (!name || !email || !message) {
      showToast('Please fill required fields');
      return;
    }

    var $btn = $(this).find('button[type="submit"]');
    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Sending...');

    setTimeout(function () {
      $btn.prop('disabled', false).text('Send Message');
      $('#contact-form')[0].reset();
      showToast('Message sent successfully! We\'ll get back to you soon.');
    }, 1200);
  });

  // ========== MEMBERSHIP FORM ==========
  $('.btn-join').on('click', function () {
    var plan = $(this).data('plan');
    $('#membershipModal').modal('show');
    $('#selected-plan').text(plan);
    $('#membership-plan').val(plan);
  });

  $('#membership-form').on('submit', function (e) {
    e.preventDefault();
    var $btn = $(this).find('button[type="submit"]');
    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Processing...');

    setTimeout(function () {
      $btn.prop('disabled', false).text('Confirm Membership');
      $('#membershipModal').modal('hide');
      $('#membership-form')[0].reset();
      showToast('Welcome to FitZone! Membership activated.');
    }, 1500);
  });

  // ========== CLASS BOOKING ==========
  $('.btn-book-class').on('click', function () {
    var className = $(this).data('class');
    $('#bookingModal').modal('show');
    $('#booking-class-name').text(className);
    $('#booking-class').val(className);
  });

  $('#booking-form').on('submit', function (e) {
    e.preventDefault();
    var $btn = $(this).find('button[type="submit"]');
    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Booking...');

    setTimeout(function () {
      $btn.prop('disabled', false).text('Confirm Booking');
      $('#bookingModal').modal('hide');
      $('#booking-form')[0].reset();
      showToast('Class booked successfully! See you there.');
    }, 1200);
  });

  // ========== TOAST ==========
  function showToast(message) {
    var $toast = $(
      '<div class="custom-toast">' +
      '<i class="bi bi-check-circle-fill"></i>' +
      '<span>' + message + '</span>' +
      '</div>'
    );
    $('.toast-container').append($toast);
    setTimeout(function () {
      $toast.fadeOut(300, function () { $(this).remove(); });
    }, 3000);
  }

  // ========== NEWSLETTER ==========
  $('#newsletter-form').on('submit', function (e) {
    e.preventDefault();
    var email = $(this).find('input').val().trim();
    if (!email) return;
    showToast('Subscribed successfully!');
    $(this)[0].reset();
  });

  // ========== GALLERY LIGHTBOX (simple) ==========
  $('.gallery-item').on('click', function () {
    var src = $(this).find('img').attr('src');
    $('#lightbox-img').attr('src', src);
    $('#lightboxModal').modal('show');
  });
});